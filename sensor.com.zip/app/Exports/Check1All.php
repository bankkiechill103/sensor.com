<?php
namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\WithHeadings;


class Check1All implements FromCollection, WithTitle, WithHeadings
{
    private $data;
    private $title;
    private $type;
    public function __construct($data, $title, $type)
    {
        $this->data = $data;
        $this->title = $title;
        $this->type = $type;
    }
    /**
     * @return Builder
     */
    public function collection()
    {
        foreach ($this->data as $key => $value) {
          if($this->type == 1 || $this->type == 4){
            $value->f1 = DateThai($value->f1, 0);
          }elseif($this->type == 2 || $this->type == 3 || $this->type == 11 || $this->type == 12){
            $value->f1 = DateThai($value->f1, 1);
          }elseif($this->type == 5 || $this->type == 6 || $this->type == 7 || $this->type == 9 || $this->type == 10){
            $value->f1 = DateThai($value->f1, 3);
          }elseif($this->type == 8){
            $value->f1 = DateThai($value->f1, 0);
          }
        }
        return $this->data;
    }

    /**
     * @return string
     */
    public function title(): string
    {
        return $this->title;
    }
    public function headings(): array
    {
      if($this->type == 1 || $this->type == 4){
        $header = ["เวลา", "LAEQ", "LMax", "L90"];
      }elseif($this->type == 2){
        $header = ["เวลา", "LAEQ", "LMax"];
      }elseif($this->type == 3){
        $header = ["เวลา", "LAEQ"];
      }elseif($this->type == 5){
        $header = ["เวลา", "Frequency X", "Vibration Reference", "Vibration X", "Result"];
      }elseif($this->type == 6){
        $header = ["เวลา", "Frequency Y", "Vibration Reference", "Vibration Y", "Result"];
      }elseif($this->type == 7){
        $header = ["เวลา", "Frequency Z", "Vibration Reference", "Vibration Z", "Result"];
      }elseif($this->type == 8){
        $header = ["เวลา", "Frequency X", "Vibration Reference", "Vibration X", "Result", "Frequency Y", "Vibration Reference", "Vibration Y", "Result", "Frequency Z", "Vibration Reference", "Vibration Z", "Result"];
      }else{
        $header = ["เวลา", "Min", "Average", "Max"];
      }
      return $header;
    }
}
?>
